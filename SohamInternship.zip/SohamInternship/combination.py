import mysql.connector
con=mysql.connector.connect(host="b0x4wqxwa89ucs5l8wdj-mysql.services.clever-cloud.com", user="uwldpbnzu2g1yneo", password="b4RpuGKyHDPOxsHZABvK", database="b0x4wqxwa89ucs5l8wdj")
curs=con.cursor()
author,publication=input("enter author & publication ").split(",")
curs.execute("select bookname from books where author='%s' and publication='%s'" %(author,publication))
a=curs.fetchall()
if a:
    for i in a:
        print(i[0])
else:
    print("book doesnt exist")



