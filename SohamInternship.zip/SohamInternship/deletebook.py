import mysql.connector
con=mysql.connector.connect(host="b0x4wqxwa89ucs5l8wdj-mysql.services.clever-cloud.com", user="uwldpbnzu2g1yneo",
password="b4RpuGKyHDPOxsHZABvK", database="b0x4wqxwa89ucs5l8wdj")
curs=con.cursor()
bookcode=input("enter bookcode ")
curs.execute("select * from books where bookcode=%d" %int(bookcode))
a=curs.fetchone()
if a:
    print(a)
    ask=input("do you want to delete? ").lower()
    if ask =="yes":
        curs.execute("delete from books where bookcode=%d" % int(bookcode))
        con.commit()
        print("data deleted successfully")
else:
    print("book doesn't found")
