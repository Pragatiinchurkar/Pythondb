import mysql.connector
con=mysql.connector.connect(host="b0x4wqxwa89ucs5l8wdj-mysql.services.clever-cloud.com", user="uwldpbnzu2g1yneo",
password="b4RpuGKyHDPOxsHZABvK", database="b0x4wqxwa89ucs5l8wdj")
curs=con.cursor()
curs.execute("select * from books")
record = curs.fetchall()
for i in record:
    for a in i:
        print(a,end=",")
    print()




