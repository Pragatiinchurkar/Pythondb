import mysql.connector
con=mysql.connector.connect(host="b0x4wqxwa89ucs5l8wdj-mysql.services.clever-cloud.com", user="uwldpbnzu2g1yneo",
password="b4RpuGKyHDPOxsHZABvK", database="b0x4wqxwa89ucs5l8wdj")
curs=con.cursor()
bookcode,review=input("enter bookcode & review ").split(",")
curs.execute("update books set review='%s' where bookcode=%d" %(review,int(bookcode)))
con.commit()
print("updated successfully")