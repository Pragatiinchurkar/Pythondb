import mysql.connector
con=mysql.connector.connect(host="b0x4wqxwa89ucs5l8wdj-mysql.services.clever-cloud.com", user="uwldpbnzu2g1yneo", password="b4RpuGKyHDPOxsHZABvK", database="b0x4wqxwa89ucs5l8wdj")
curs=con.cursor()
curs.execute("alter table books add column review varchar(200) ")
con.commit()
print("column added successfully")
