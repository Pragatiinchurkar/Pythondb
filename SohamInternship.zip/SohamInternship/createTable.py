import mysql.connector
con=mysql.connector.connect(host="b0x4wqxwa89ucs5l8wdj-mysql.services.clever-cloud.com", user="uwldpbnzu2g1yneo",
password="b4RpuGKyHDPOxsHZABvK", database="b0x4wqxwa89ucs5l8wdj")
curs=con.cursor()
curs.execute("create table books(bookcode int primary key, bookname varchar(20), category varchar(20), author varchar(20), publication varchar(20), edition varchar(20), price float)")
con.commit()
print("table created successfully")
con.close()